# Ported engine definitions. Original launchers and UI entry points are excluded.
from __future__ import annotations
import math
import os
import threading
import time
from dataclasses import dataclass
from typing import Optional
CARRIER_HZ = 7.83

class SchumannCarrier:
    """Continuous 7.83 Hz reference oscillator for application visuals/math."""

    def __init__(self, frequency_hz: float=CARRIER_HZ):
        self.frequency_hz = float(frequency_hz)
        self._epoch = time.monotonic()

    def sample(self, now: Optional[float]=None) -> dict:
        elapsed = (time.monotonic() if now is None else now) - self._epoch
        phase = math.tau * self.frequency_hz * elapsed
        return {'frequency_hz': self.frequency_hz, 'phase_rad': math.fmod(phase, math.tau), 'elapsed_s': elapsed, 'sin': math.sin(phase), 'cos': math.cos(phase)}

@dataclass(frozen=True)
class ActivitySnapshot:
    sampled_at: float
    cpu_percent: Optional[float]
    memory_percent: Optional[float]
    memory_used_gb: Optional[float]
    memory_total_gb: Optional[float]
    network_sent_bytes_sec: Optional[float]
    network_recv_bytes_sec: Optional[float]
    gpu_percent: Optional[float]
    gpu_memory_percent: Optional[float]
    source: str

class SystemActivitySampler:
    """Read local CPU, memory, and aggregate network counters when available.

    psutil is used when it is already installed. On Windows, CPU and memory
    fall back to native system counters. Unsupported readings remain None.
    """

    def __init__(self, minimum_interval: float=0.25):
        self.minimum_interval = max(0.1, float(minimum_interval))
        self._lock = threading.Lock()
        self._psutil = None
        self._last_sample = 0.0
        self._last_net = None
        self._last_net_time = None
        self._snapshot = ActivitySnapshot(time.time(), None, None, None, None, None, None, None, None, 'unavailable')
        self._win_cpu = None
        self._win_memory = None
        try:
            import psutil
            self._psutil = psutil
            psutil.cpu_percent(interval=None)
        except Exception:
            pass
        self._nvml = None
        self._nvml_handle = None
        try:
            import pynvml
            pynvml.nvmlInit()
            self._nvml = pynvml
            self._nvml_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        except Exception:
            self._nvml = None
            self._nvml_handle = None
        if self._psutil is None and os.name == 'nt':
            self._initialize_windows_counters()

    def _initialize_windows_counters(self):
        try:
            import ctypes
            from ctypes import wintypes

            class FILETIME(ctypes.Structure):
                _fields_ = [('dwLowDateTime', wintypes.DWORD), ('dwHighDateTime', wintypes.DWORD)]

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [('dwLength', wintypes.DWORD), ('dwMemoryLoad', wintypes.DWORD), ('ullTotalPhys', ctypes.c_ulonglong), ('ullAvailPhys', ctypes.c_ulonglong), ('ullTotalPageFile', ctypes.c_ulonglong), ('ullAvailPageFile', ctypes.c_ulonglong), ('ullTotalVirtual', ctypes.c_ulonglong), ('ullAvailVirtual', ctypes.c_ulonglong), ('ullAvailExtendedVirtual', ctypes.c_ulonglong)]

            def ft_value(value):
                return int(value.dwHighDateTime) << 32 | int(value.dwLowDateTime)

            def sample_cpu():
                idle, kernel, user = (FILETIME(), FILETIME(), FILETIME())
                if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
                    return None
                return (ft_value(idle), ft_value(kernel), ft_value(user))

            def sample_memory():
                status = MEMORYSTATUSEX()
                status.dwLength = ctypes.sizeof(status)
                if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                    return None
                total = int(status.ullTotalPhys)
                available = int(status.ullAvailPhys)
                used = total - available
                return (float(status.dwMemoryLoad), used / 1024 ** 3, total / 1024 ** 3)
            self._win_cpu = sample_cpu
            self._win_memory = sample_memory
            self._previous_cpu_times = sample_cpu()
        except Exception:
            self._win_cpu = self._win_memory = None

    @staticmethod
    def _rate(current, previous, elapsed):
        if current is None or previous is None or elapsed <= 0:
            return None
        return max(0.0, (int(current) - int(previous)) / elapsed)

    def snapshot(self, force: bool=False) -> ActivitySnapshot:
        now_mono = time.monotonic()
        with self._lock:
            if not force and now_mono - self._last_sample < self.minimum_interval:
                return self._snapshot
            cpu = memory = used_gb = total_gb = sent_rate = recv_rate = gpu = gpu_memory = None
            source_parts = []
            if self._psutil is not None:
                try:
                    cpu = float(self._psutil.cpu_percent(interval=None))
                    source_parts.append('psutil CPU')
                except Exception:
                    pass
                try:
                    vm = self._psutil.virtual_memory()
                    memory = float(vm.percent)
                    used_gb = int(vm.used) / 1024 ** 3
                    total_gb = int(vm.total) / 1024 ** 3
                    source_parts.append('psutil memory')
                except Exception:
                    pass
                try:
                    net = self._psutil.net_io_counters()
                    current_net = (int(net.bytes_sent), int(net.bytes_recv))
                    if self._last_net is not None and self._last_net_time is not None:
                        elapsed = max(0.001, now_mono - self._last_net_time)
                        sent_rate = self._rate(current_net[0], self._last_net[0], elapsed)
                        recv_rate = self._rate(current_net[1], self._last_net[1], elapsed)
                    self._last_net = current_net
                    self._last_net_time = now_mono
                    source_parts.append('aggregate network counters')
                except Exception:
                    pass
            elif os.name == 'nt':
                if self._win_cpu:
                    try:
                        current = self._win_cpu()
                        previous = self._previous_cpu_times
                        self._previous_cpu_times = current
                        if current and previous:
                            idle_delta = current[0] - previous[0]
                            total_delta = current[1] - previous[1] + (current[2] - previous[2])
                            if total_delta > 0:
                                cpu = max(0.0, min(100.0, 100.0 * (1.0 - idle_delta / total_delta)))
                        source_parts.append('Windows system CPU counters')
                    except Exception:
                        pass
                if self._win_memory:
                    try:
                        memory, used_gb, total_gb = self._win_memory()
                        source_parts.append('Windows physical memory counters')
                    except Exception:
                        pass
            if self._nvml is not None and self._nvml_handle is not None:
                try:
                    util = self._nvml.nvmlDeviceGetUtilizationRates(self._nvml_handle)
                    gpu = float(util.gpu)
                    mem = self._nvml.nvmlDeviceGetMemoryInfo(self._nvml_handle)
                    if int(mem.total) > 0:
                        gpu_memory = 100.0 * int(mem.used) / int(mem.total)
                    source_parts.append('NVIDIA NVML GPU counters')
                except Exception:
                    pass
            source = '; '.join(source_parts) if source_parts else 'unavailable (install psutil for full CPU/RAM/network metrics)'
            self._snapshot = ActivitySnapshot(sampled_at=time.time(), cpu_percent=cpu, memory_percent=memory, memory_used_gb=used_gb, memory_total_gb=total_gb, network_sent_bytes_sec=sent_rate, network_recv_bytes_sec=recv_rate, gpu_percent=gpu, gpu_memory_percent=gpu_memory, source=source)
            self._last_sample = now_mono
            return self._snapshot
_shared_sampler = None
_shared_carrier = None
_shared_lock = threading.Lock()

def get_system_sampler() -> SystemActivitySampler:
    global _shared_sampler
    with _shared_lock:
        if _shared_sampler is None:
            _shared_sampler = SystemActivitySampler()
        return _shared_sampler

def get_carrier() -> SchumannCarrier:
    global _shared_carrier
    with _shared_lock:
        if _shared_carrier is None:
            _shared_carrier = SchumannCarrier()
        return _shared_carrier

def format_rate(value: Optional[float]) -> str:
    if value is None:
        return 'unavailable'
    units = ('B/s', 'KB/s', 'MB/s', 'GB/s')
    rate = max(0.0, value)
    index = 0
    while rate >= 1024 and index < len(units) - 1:
        rate /= 1024
        index += 1
    return f'{rate:.1f} {units[index]}'
