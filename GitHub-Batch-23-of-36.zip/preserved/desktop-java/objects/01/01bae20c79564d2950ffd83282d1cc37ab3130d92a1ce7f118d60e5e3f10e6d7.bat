@echo off

java KernelBridge