@echo off

java ConflictGraphApp