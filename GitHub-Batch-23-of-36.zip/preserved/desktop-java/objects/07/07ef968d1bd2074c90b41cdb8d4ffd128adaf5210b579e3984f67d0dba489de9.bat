@echo off

java GodMindLanBridge
