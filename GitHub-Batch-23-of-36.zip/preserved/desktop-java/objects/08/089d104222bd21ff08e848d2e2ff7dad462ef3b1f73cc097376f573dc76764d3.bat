@echo off

java GlobalBankAuditService