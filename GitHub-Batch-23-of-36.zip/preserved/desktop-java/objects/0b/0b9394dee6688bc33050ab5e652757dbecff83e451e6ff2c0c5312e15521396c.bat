@echo off

java EngineOrchestrationGrid