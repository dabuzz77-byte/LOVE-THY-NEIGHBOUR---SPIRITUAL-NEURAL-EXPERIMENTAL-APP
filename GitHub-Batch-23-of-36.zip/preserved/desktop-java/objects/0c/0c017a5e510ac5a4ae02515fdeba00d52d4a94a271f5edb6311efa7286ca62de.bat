@echo off

java GridServer