@echo off

java RoadrunnerVelocityEngine