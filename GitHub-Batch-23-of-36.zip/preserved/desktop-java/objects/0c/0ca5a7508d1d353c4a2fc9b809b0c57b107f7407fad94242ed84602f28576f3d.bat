@echo off

java InferenceBeacon