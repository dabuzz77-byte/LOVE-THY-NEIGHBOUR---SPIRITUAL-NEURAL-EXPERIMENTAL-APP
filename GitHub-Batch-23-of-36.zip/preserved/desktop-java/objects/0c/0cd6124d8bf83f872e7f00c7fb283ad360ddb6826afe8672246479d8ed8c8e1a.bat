echo off 

java GhostCryptoInferenceMoldEngine