@echo off

java CorporateGatewayConsole