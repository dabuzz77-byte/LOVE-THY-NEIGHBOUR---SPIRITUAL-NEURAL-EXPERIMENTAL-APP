@echo off

java InterpreterCore