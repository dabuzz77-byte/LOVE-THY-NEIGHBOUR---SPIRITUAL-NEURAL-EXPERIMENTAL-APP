@echo off

java GodModeGridProcessor