@echo off

java EconomicFloorGridVisualizer