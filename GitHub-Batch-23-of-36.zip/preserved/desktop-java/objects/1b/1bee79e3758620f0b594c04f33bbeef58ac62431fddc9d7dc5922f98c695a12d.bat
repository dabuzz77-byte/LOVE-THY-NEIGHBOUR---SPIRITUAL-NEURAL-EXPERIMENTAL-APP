@echo off

java MasterGridParityEngine