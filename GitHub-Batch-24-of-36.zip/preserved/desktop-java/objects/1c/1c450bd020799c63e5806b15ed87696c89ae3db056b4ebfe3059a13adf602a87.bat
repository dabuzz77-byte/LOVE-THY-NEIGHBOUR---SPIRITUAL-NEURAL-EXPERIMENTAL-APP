@echo off

java SessionBridgeHistory
