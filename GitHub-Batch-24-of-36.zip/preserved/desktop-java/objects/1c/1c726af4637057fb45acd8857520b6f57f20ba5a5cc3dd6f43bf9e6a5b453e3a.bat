@echo off

java CoreInteractionSystemGUI