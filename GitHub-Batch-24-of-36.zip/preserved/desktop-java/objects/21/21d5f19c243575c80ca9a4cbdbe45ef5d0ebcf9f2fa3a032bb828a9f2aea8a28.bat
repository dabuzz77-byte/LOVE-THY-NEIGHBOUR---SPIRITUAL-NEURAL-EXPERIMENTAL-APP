@echo off

java MicrocosmicOrbitApp