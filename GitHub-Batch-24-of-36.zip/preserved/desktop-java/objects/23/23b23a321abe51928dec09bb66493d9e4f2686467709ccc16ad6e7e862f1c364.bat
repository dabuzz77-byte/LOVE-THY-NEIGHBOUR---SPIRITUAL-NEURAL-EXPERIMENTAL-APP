@echo off

java JavaGridMonitor