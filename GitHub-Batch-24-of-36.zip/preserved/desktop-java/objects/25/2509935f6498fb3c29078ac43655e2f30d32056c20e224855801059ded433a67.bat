@echo off

java CosmicAlignmentHub
