@echo off

java MasterSubstrateApp
