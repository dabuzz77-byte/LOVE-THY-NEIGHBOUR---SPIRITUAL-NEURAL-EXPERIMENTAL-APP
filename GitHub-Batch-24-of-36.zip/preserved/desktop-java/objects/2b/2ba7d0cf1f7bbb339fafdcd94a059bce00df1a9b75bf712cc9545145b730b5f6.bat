@echo off

java GodSelfInteractEngine