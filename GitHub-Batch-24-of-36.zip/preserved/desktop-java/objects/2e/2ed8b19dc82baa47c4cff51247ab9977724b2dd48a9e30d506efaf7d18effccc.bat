@echo off

java GhostOutpostInterface