@echo off

java SessionArchive
