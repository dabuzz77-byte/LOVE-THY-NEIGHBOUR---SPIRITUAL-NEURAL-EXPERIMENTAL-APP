@echo off

java FluxInterfaceBus