@echo off

java LanBusDesktopApp