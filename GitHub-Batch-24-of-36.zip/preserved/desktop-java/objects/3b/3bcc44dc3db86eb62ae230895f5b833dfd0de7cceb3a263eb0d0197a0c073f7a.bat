@echo off

java  SchumannInterfaceApp