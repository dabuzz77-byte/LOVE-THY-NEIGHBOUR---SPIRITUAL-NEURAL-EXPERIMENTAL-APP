@echo off

java QuantumBridgeLink