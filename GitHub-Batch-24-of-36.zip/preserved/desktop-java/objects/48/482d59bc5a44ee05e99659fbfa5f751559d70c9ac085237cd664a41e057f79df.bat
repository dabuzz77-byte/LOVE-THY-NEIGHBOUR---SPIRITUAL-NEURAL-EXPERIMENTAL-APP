@echo off

java ConvergentAlignmentEngine