@echo off



java AllPrevSystemDashboard
