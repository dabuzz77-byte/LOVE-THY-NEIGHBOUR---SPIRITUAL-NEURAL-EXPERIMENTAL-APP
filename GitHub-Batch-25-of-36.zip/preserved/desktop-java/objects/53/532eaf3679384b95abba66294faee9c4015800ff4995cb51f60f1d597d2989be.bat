@echo off

java MicrocosmicOrbitDashboard