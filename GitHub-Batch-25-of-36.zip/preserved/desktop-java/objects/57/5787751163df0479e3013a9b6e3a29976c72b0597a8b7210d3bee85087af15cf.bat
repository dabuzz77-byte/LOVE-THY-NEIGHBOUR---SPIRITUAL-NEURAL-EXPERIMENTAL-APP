@echo off

java NetworkConvergenceHub