@echo off

java LocalInferenceBusEngine