@echo off

java FinancialRestitutionVisualizer