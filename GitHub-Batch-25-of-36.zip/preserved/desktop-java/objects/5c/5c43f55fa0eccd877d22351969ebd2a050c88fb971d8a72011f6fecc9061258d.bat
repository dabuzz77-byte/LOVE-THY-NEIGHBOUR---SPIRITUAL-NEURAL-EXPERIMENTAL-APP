@echo off

java GodMindMasterEngine