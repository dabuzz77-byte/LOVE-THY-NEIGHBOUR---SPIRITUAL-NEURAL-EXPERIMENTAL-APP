@echo off

java LANCoordinatorEngine