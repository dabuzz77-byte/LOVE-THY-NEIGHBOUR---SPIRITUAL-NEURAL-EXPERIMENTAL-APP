@echo off

java QuantumLogicExplorer