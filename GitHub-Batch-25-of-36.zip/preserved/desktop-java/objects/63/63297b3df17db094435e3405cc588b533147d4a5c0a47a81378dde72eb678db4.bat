@echo off

java QuantumSidebarBridgeApp
