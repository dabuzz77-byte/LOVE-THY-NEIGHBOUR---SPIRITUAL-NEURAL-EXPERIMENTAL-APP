@echo off


java OmniKeyspaceLauncher
