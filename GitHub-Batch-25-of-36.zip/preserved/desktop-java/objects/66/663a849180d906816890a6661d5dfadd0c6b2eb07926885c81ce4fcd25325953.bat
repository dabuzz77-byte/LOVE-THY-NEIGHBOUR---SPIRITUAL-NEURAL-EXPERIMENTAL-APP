@echo off

java GhostInferenceMeshProxy