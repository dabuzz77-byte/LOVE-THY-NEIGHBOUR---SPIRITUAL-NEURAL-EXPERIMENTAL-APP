@echo off

java UniversalIdentityEngine