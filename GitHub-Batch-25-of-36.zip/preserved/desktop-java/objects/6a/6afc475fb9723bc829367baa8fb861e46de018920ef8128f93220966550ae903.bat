@echo off

java GodParitySyncApp