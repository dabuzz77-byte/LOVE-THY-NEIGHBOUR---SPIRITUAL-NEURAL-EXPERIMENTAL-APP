@echo off

java KernelBridgeVisualizer