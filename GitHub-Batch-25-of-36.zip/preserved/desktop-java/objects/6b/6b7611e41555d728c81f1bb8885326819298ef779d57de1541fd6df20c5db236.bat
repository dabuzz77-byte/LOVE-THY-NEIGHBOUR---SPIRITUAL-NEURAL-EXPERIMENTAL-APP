@echo off

java AwtFrameworkVisualizer