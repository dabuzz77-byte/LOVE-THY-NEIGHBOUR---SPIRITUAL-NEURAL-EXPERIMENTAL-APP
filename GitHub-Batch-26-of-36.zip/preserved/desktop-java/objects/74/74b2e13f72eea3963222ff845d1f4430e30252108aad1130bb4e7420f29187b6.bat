@echo off

java QuantumMindConsole