@echo off

java InfiniteGodMindMeshBridge