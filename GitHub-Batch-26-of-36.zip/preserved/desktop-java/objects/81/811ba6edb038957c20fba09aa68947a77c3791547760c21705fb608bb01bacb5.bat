@echo off

java GodMindInteractiveVisualizer