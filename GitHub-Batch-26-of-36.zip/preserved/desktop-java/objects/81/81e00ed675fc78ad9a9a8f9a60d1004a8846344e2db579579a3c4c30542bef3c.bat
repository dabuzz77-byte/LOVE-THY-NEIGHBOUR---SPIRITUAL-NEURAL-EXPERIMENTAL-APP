@echo off

java MatterRealignmentEngine