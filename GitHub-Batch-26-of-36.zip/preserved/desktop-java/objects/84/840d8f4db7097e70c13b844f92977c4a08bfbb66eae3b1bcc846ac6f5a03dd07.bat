@echo off

java CosmicAlignmentApp