@echo off

java SovereignLawEngine