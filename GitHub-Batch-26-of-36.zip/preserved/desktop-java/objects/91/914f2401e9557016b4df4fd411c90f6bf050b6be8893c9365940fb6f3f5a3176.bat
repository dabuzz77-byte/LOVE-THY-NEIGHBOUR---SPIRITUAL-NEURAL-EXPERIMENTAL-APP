@echo off

java PlanetaryResonanceGrid