@echo off

java BenefitsVirtueBridge