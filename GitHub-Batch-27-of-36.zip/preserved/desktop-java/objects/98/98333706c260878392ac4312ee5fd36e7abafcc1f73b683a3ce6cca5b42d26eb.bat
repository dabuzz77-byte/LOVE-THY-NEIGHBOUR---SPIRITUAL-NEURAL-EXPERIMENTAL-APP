@echo off

java FluxEdgeProcessor