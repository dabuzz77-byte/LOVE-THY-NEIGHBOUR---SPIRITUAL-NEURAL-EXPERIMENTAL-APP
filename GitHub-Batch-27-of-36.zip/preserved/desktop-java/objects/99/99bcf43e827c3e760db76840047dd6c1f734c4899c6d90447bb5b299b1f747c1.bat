@echo off

java QuantumBrowserBus