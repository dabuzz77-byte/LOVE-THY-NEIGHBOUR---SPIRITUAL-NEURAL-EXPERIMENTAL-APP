@echo off

java BiTerQuantumBridge