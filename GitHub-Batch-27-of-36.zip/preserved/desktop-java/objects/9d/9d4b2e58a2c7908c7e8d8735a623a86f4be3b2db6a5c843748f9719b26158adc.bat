@echo off

java SessionDataArchive
