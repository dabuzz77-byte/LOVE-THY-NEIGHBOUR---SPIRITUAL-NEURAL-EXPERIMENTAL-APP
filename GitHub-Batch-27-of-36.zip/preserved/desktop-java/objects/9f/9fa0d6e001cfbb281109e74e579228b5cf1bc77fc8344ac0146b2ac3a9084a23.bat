@echo off

java GodMindDashboard