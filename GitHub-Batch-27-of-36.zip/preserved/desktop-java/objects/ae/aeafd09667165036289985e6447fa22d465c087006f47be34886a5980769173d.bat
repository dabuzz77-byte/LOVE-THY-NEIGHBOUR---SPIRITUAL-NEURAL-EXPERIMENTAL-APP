@echo off

java NwolbDepositBridge