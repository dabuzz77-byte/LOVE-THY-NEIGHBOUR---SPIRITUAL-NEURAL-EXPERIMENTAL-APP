@echo off

java ConsolidatedConsole