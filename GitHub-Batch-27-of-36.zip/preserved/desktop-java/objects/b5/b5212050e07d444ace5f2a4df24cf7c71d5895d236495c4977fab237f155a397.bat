@echo off

java GodInterfaceMainApp