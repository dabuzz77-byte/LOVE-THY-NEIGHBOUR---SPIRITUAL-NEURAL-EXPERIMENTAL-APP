@echo off

java GodMindShipVisualizer
