@echo off

java InferenceLabEngine