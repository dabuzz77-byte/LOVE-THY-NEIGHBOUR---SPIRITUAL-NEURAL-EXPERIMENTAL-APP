@echo off

java GeminiInferenceBridge