@echo off

java GodMindParityRuntime