@echo off

java ClownResolverEngine