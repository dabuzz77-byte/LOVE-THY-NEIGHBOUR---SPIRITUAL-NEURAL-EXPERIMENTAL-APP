@echo off

java DistantInferenceStream