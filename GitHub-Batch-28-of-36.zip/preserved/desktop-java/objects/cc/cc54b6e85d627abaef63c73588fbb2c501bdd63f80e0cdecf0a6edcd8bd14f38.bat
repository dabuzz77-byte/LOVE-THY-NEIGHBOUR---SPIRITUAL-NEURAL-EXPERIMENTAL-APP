@echo off

java ProductionControlConsole