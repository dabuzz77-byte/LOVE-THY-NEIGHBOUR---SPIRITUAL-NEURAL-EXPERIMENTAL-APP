@echo off

java FederatedSovereignSystem