@echo off

java GodEngineInteractConsole