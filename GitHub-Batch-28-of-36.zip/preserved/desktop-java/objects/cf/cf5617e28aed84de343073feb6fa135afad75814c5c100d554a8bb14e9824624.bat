@echo off

java QBiTerEngine