@echo off

java GhostSignMeshBridge