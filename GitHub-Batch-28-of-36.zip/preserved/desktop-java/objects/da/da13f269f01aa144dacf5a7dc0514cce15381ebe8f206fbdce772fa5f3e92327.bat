@echo off

java DeepestStrataEngine
