@ echo off

java  OmniZenithLoopEngine