@echo off

java ElementalRecursiveWorld