@echo off

java StickForestMatrixApp