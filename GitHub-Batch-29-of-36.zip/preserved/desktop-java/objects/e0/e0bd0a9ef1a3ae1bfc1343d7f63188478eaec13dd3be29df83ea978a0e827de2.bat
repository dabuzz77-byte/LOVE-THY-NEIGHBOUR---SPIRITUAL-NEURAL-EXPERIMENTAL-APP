@echo off

java UniversalRestitutionMatrixApp