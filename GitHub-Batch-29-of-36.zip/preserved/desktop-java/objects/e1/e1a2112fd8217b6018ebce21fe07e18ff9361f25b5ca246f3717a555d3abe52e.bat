@echo off


java RecursiveTesseractLoop