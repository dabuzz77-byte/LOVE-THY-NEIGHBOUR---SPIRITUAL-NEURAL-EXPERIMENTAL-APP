@echo off

java SandcastleKarmicWorld