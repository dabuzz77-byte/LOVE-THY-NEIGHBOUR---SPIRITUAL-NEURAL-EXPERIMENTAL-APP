@echo off

java OmniVirtueBalancerGUI