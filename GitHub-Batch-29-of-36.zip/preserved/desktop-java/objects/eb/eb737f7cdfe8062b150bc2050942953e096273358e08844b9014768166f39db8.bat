@echo off

java SystemGridExplorer