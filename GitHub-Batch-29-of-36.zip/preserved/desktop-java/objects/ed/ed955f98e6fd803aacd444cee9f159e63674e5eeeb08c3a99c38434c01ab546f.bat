@echo off

java GoogleBillingInferenceBridge