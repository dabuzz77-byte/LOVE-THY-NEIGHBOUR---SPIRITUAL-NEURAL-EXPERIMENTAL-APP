@echo off

java SessionMasterEngine