@echo off

java VirtueDashboard