@echo off

java StandaloneStreamingService