@echo off

java MicrocosmicOrbitEngine
