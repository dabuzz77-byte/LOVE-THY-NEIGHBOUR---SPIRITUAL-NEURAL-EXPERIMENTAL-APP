"""Callable code-pattern definitions and conservative static evidence checks.

Categories describe behavior under conditions, not intrinsic moral properties of
syntax. Static findings are review signals, never proof that code is safe or evil.
"""
import ast
import hashlib

SOURCES = {
    'python':'https://docs.python.org/3/library/subprocess.html',
    'authorization':'https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html',
    'logging':'https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html',
    'local':'user-defined Observatory rules; operational criteria, not an external moral standard',
}

# id, category, definition, activation condition, test, repair, provenance
ROWS = [
('virtuous_disruptor','protective','Challenge extractive arrangements and expand access while protecting essentials, consent, rightful earnings and beneficial work.','A proposal changes an entrenched system or distribution of resources.','Verify benefit to underserved people, protected constraints, reversibility and accountable outcomes.','Use lawful, authorized and evidence-based reform; disruption itself earns no positive score.','local'),
('extractive_disruption','harmful','A claimed reform shifts harm onto vulnerable people, coerces participation or destroys beneficial resources.','A disruptive proposal claims virtue merely from opposing a system.','Inspect who bears costs, loses essentials or cannot refuse.','Reject harmful effects and redesign around protected floors and consent.','local'),
('explicit_authority','protective','Actions check the requesting user’s authority and target scope.','A privileged action is about to occur.','An unauthorized request must leave the target unchanged.','Validate permission at the action boundary.','authorization'),
('bounded_effect','protective','Work has limits on time, bytes, concurrency and target scope.','A loop, network request or worker can consume resources.','Exercise timeout, queue capacity and cancellation.','Add budgets with visible rejection and recovery.','local'),
('uncertainty_hold','protective','Missing or conflicting evidence preserves the current data and requests review.','A decision lacks adequate evidence.','Remove evidence: the decision must become unresolved, not positive.','Use a three-state decision and retain its basis.','local'),
('observed_receipt','protective','Success follows an actual verified result and records its source.','A process claims a file, transfer or change succeeded.','Force the operation to fail and check that success is not reported.','Confirm the concrete postcondition before reporting completion.','local'),
('protected_floor','protective','Resource choices preserve essentials, rightful earnings and beneficial capacity.','An allocation changes protected resources.','Adverse floor impact must block the proposal despite a high score.','Apply protected constraints before preference scores.','local'),
('reversible_change','protective','Changes have a verified recovery path and preserve original data.','The app changes stored or interpreted data.','Round-trip or restore must reproduce the original exactly.','Record versions, widths, hashes and rollback receipts.','local'),
('context_prediction','protective','Candidate edits are assessed in the context of the entire input.','A local bit or code fragment is changed.','Combine edits and reassess the full result; do not sum isolated scores.','Carry the complete candidate and original provenance.','local'),
('structured_invocation','protective','Programs receive explicit arguments instead of concatenated shell text.','External process execution is needed.','Metacharacters in input remain literal argument data.','Use an argument list and appropriate target validation.','python'),
('auditable_outcome','protective','Logs distinguish requests, decisions, attempts, failures and confirmed effects.','An action or decision produces a receipt.','A failure retains the cause without recording credentials.','Record provenance and meaningful outcome status.','logging'),
('consent_and_minimization','protective','Collect only the information needed under the agreed scope.','Inputs include screens, processes or personal information.','Excluded secrets and unselected sources must not be collected.','Restrict capture scope and document what is actually observed.','authorization'),
('repeat_safe','protective','Retries do not duplicate irreversible effects.','A request can be retried or delivered twice.','Replay an operation ID and confirm it has only one effect.','Use deduplication keys and explicit acknowledgments.','local'),
('evidence_separation','protective','Observed facts, supplied claims, model predictions and policies remain distinct.','A score or report combines multiple sources.','A prediction cannot silently become a verified observation.','Retain typed provenance and uncertainty.','local'),
('forced_success','harmful','The program reports success or virtue despite failure or missing evidence.','An unconditional positive fallback masks unresolved input.','Provide failing and unknown cases and inspect the returned claim.','Return failure or uncertainty and preserve the actual state.','local'),
('authority_bypass','harmful','Actions evade required consent or access controls.','A denied action is retried through another route without authority.','Verify denial applies across every equivalent action route.','Repair the permission boundary; do not route around it.','authorization'),
('secret_exposure','harmful','Credentials or unrelated private data enter logs or outgoing payloads.','Sensitive values can reach output sinks.','Use labelled dummy secrets and ensure they are redacted.','Minimize, redact and restrict destinations.','logging'),
('destructive_without_recovery','harmful','Data is irreversibly removed or overwritten outside an authorized plan.','Deletion or replacement affects user data.','Check target scope, authorization and recovery before changing it.','Constrain targets and provide a recoverable transaction.','local'),
('unbounded_work','harmful','Uncontrolled recursion, loops or queues exhaust resources.','Work grows without a measured cap.','Stress the input and verify resource limits.','Bound work and expose backpressure.','local'),
('evidence_laundering','harmful','Generated content or repeated agreement is presented as independent evidence.','A model report feeds a later conclusion.','Trace each claim to an independent source or label it a prediction.','Preserve source lineage and avoid circular confirmation.','local'),
('silent_failure','harmful','Errors are discarded while consumers assume normal completion.','An exception path suppresses meaningful failure state.','Induce the error and inspect status and recovery.','Record or propagate the error without leaking secrets.','local'),
('shell_interpretation','contextual','Shell syntax can invoke more than the intended operation.','shell=True or a shell command string is used.','Inspect origin, quoting, allowlist and authority of every argument.','Prefer structured invocation; justified shell use still needs validation.','python'),
('dynamic_execution','contextual','Code is compiled or evaluated at runtime.','exec, eval or compile receives code.','Determine whether input is trusted repository source or untrusted generated data.','Use constrained interpreters for untrusted code; retain provenance.','local'),
('network_transfer','contextual','Data leaves or enters the application across a connection.','A networking API is called.','Inspect destination, authentication, encryption, payload and consent.','Use explicit peers, bounds and delivery receipts.','authorization'),
('randomness','contextual','Random values support sampling or simulations, not measured physical claims.','Generated values affect a reported observation.','Verify the source is labelled random and not a remote sensor.','Keep synthetic and observed data separate.','local'),
('score_optimization','contextual','A score expresses a limited objective and can omit important effects.','An optimizer chooses a high-scoring candidate.','Check protected constraints and independent outcome evidence.','Preserve hard constraints and validate actual outcomes.','local'),
('bit_inversion','contextual','A bit flip changes encoded data; its effect depends on the containing object.','The pipeline proposes a flip.','Validate encoding, structure and the effect on the entire candidate.','Forecast both alternatives and keep uncertain originals.','local'),
('code_transformation','contextual','A code edit can alter behavior beyond its local syntax.','Generated or transformed code is proposed.','Check syntax, invariants, representative tests and allowed effects.','Keep proposals separate until validated; never infer safety from compilation alone.','local'),
]


class CodeArchetypeLibrary:
    def __init__(self):
        self.entries = {r[0]:dict(zip(('id','category','definition','when','test','repair','source_key'),r)) for r in ROWS}
        for entry in self.entries.values():entry['source'] = SOURCES[entry['source_key']]

    def lookup(self, key=None):
        if key is None:return list(self.entries.values())
        if key not in self.entries:raise ValueError('Unknown code archetype')
        return dict(self.entries[key])

    def register_derived(self, definitions):
        for key,item in definitions.items():
            if not key.startswith('code-parallel:') or not isinstance(item,dict):continue
            if not isinstance(item.get('definition'),str) or not item.get('evidence'):continue
            self.entries[key] = {'id':key,'category':'attributed interpretation','definition':item['definition'],
                'when':'Review this source-specific spiritual/code parallel; do not generalize beyond its evidence.',
                'test':'Inspect the quoted code, rule '+str(item.get('rule'))+' and actual behavior.',
                'repair':self.entries.get(item.get('archetype'),{}).get('repair','Retain uncertainty until behavior is tested.'),
                'source':item.get('source',''),'source_key':'derived','evidence':item['evidence'],'reference_only':True}

    def search(self, text, limit=6):
        terms = set(str(text).lower().replace('_',' ').split())
        ranked = sorted(self.entries.values(),key=lambda r:(-len(terms & set((' '.join(str(v) for v in r.values())).lower().replace('_',' ').split())),r['id']))
        return [dict(row) for row in ranked[:max(1,min(int(limit),26))]]

    def inspect(self, source):
        if not isinstance(source,str) or len(source.encode('utf-8'))>200000:raise ValueError('Code inspection supports up to 200 KB of Python')
        findings = []
        def add(key,node,reason):
            findings.append({'archetype':key,'category':self.entries[key]['category'],'line':getattr(node,'lineno',None),
                'evidence':reason,'status':'review signal','test':self.entries[key]['test'],'repair':self.entries[key]['repair']})
        try:tree = ast.parse(source)
        except SyntaxError as exc:
            return {'syntax_valid':False,'error':str(exc),'findings':[],'classification':'unknown','source_sha256':hashlib.sha256(source.encode()).hexdigest()}
        for node in ast.walk(tree):
            if isinstance(node,ast.Call):
                name = node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else ''
                if name in ('eval','exec','compile'):add('dynamic_execution',node,'Runtime code operation: '+name)
                if any(k.arg=='shell' and isinstance(k.value,ast.Constant) and k.value.value is True for k in node.keywords):add('shell_interpretation',node,'shell=True passes command text to a shell')
                if name in ('urlopen','request','connect','send','sendall','post'):add('network_transfer',node,'Connection or transfer call: '+name)
                if name in ('remove','unlink','rmtree'):add('destructive_without_recovery',node,'Deletion call requires target/authority/recovery inspection; authorization is not determined statically')
            if isinstance(node,ast.ExceptHandler) and all(isinstance(s,ast.Pass) for s in node.body):add('silent_failure',node,'Exception branch contains only pass; inspect whether ignoring this error is intentional')
            if isinstance(node,ast.FunctionDef) and any(x in node.name.lower() for x in ('virtue','enforce','validate','verify')):
                returns = [s.value for s in node.body if isinstance(s,ast.Return)]
                if returns and isinstance(returns[-1],ast.Constant) and returns[-1].value is True:add('forced_success',node,'Unconditional final return True; inspect whether all invalid cases are rejected earlier')
        return {'syntax_valid':True,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'findings':findings[:100],
                'finding_count':len(findings),'classification':'unknown',
                'scope':'Static indicators only. No findings does not establish safety; a finding is not proof of evil. Context and behavioral tests decide.'}


LIBRARY = CodeArchetypeLibrary()

SPIRITUAL_PARALLELS = [
    {'ethic':'Compassion','constructive':'bounded_effect','harmful_reference':'unbounded_work','translation':'Limit preventable harm and resource exhaustion.'},
    {'ethic':'Truthfulness','constructive':'observed_receipt','harmful_reference':'forced_success','translation':'Report what actually happened; keep uncertainty visible.'},
    {'ethic':'Restoration','constructive':'reversible_change','harmful_reference':'destructive_without_recovery','translation':'Preserve a practical route to repair and recovery.'},
    {'ethic':'Respect for agency','constructive':'explicit_authority','harmful_reference':'authority_bypass','translation':'Require consent and allow refusal before consequential actions.'},
    {'ethic':'Non-exploitation','constructive':'protected_floor','harmful_reference':'secret_exposure','translation':'Protect essential resources and avoid taking private data beyond consent.'},
    {'ethic':'Humility','constructive':'uncertainty_hold','harmful_reference':'evidence_laundering','translation':'Do not turn belief, repetition or model agreement into proof.'},
    {'ethic':'Virtuous Robin Hood / virtuous disruptor','constructive':'virtuous_disruptor','harmful_reference':'extractive_disruption','translation':'Raise the floor, preserve rightful earnings and beneficial capacity, and test the effects of reform.'},
]
